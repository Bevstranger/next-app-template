/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
self["webpackHotUpdate_N_E"]("app/template",{

/***/ "(app-pages-browser)/./components/HeaderMegaMenu.module.css":
/*!**********************************************!*\
  !*** ./components/HeaderMegaMenu.module.css ***!
  \**********************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

eval(__webpack_require__.ts("// extracted by mini-css-extract-plugin\nmodule.exports = {\"header\":\"HeaderMegaMenu_header__kWbhr\",\"link\":\"HeaderMegaMenu_link__QKcNo\",\"subLink\":\"HeaderMegaMenu_subLink__yUVGu\",\"dropdownFooter\":\"HeaderMegaMenu_dropdownFooter__p3Rb9\",\"logo\":\"HeaderMegaMenu_logo__HzT_D\"};\n    if(true) {\n      // 1742402329419\n      var cssReload = __webpack_require__(/*! ./node_modules/next/dist/compiled/mini-css-extract-plugin/hmr/hotModuleReplacement.js */ \"(app-pages-browser)/./node_modules/next/dist/compiled/mini-css-extract-plugin/hmr/hotModuleReplacement.js\")(module.id, {\"publicPath\":\"/_next/\",\"esModule\":false,\"locals\":true});\n      module.hot.dispose(cssReload);\n      \n    }\n  \nmodule.exports.__checksum = \"57d8efde80d7\"\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwcC1wYWdlcy1icm93c2VyKS8uL2NvbXBvbmVudHMvSGVhZGVyTWVnYU1lbnUubW9kdWxlLmNzcyIsIm1hcHBpbmdzIjoiQUFBQTtBQUNBLGtCQUFrQjtBQUNsQixPQUFPLElBQVU7QUFDakI7QUFDQSxzQkFBc0IsbUJBQU8sQ0FBQyx3TUFBcUgsY0FBYyxzREFBc0Q7QUFDdk4sTUFBTSxVQUFVO0FBQ2hCO0FBQ0E7QUFDQTtBQUNBLHlCQUF5QiIsInNvdXJjZXMiOlsiQzpcXFdlYlxcbmV4dGpzXFxuZXh0LWFwcC10ZW1wbGF0ZVxcY29tcG9uZW50c1xcSGVhZGVyTWVnYU1lbnUubW9kdWxlLmNzcyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBleHRyYWN0ZWQgYnkgbWluaS1jc3MtZXh0cmFjdC1wbHVnaW5cbm1vZHVsZS5leHBvcnRzID0ge1wiaGVhZGVyXCI6XCJIZWFkZXJNZWdhTWVudV9oZWFkZXJfX2tXYmhyXCIsXCJsaW5rXCI6XCJIZWFkZXJNZWdhTWVudV9saW5rX19RS2NOb1wiLFwic3ViTGlua1wiOlwiSGVhZGVyTWVnYU1lbnVfc3ViTGlua19feVVWR3VcIixcImRyb3Bkb3duRm9vdGVyXCI6XCJIZWFkZXJNZWdhTWVudV9kcm9wZG93bkZvb3Rlcl9fcDNSYjlcIixcImxvZ29cIjpcIkhlYWRlck1lZ2FNZW51X2xvZ29fX0h6VF9EXCJ9O1xuICAgIGlmKG1vZHVsZS5ob3QpIHtcbiAgICAgIC8vIDE3NDI0MDIzMjk0MTlcbiAgICAgIHZhciBjc3NSZWxvYWQgPSByZXF1aXJlKFwiQzovV2ViL25leHRqcy9uZXh0LWFwcC10ZW1wbGF0ZS9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2NvbXBpbGVkL21pbmktY3NzLWV4dHJhY3QtcGx1Z2luL2htci9ob3RNb2R1bGVSZXBsYWNlbWVudC5qc1wiKShtb2R1bGUuaWQsIHtcInB1YmxpY1BhdGhcIjpcIi9fbmV4dC9cIixcImVzTW9kdWxlXCI6ZmFsc2UsXCJsb2NhbHNcIjp0cnVlfSk7XG4gICAgICBtb2R1bGUuaG90LmRpc3Bvc2UoY3NzUmVsb2FkKTtcbiAgICAgIFxuICAgIH1cbiAgXG5tb2R1bGUuZXhwb3J0cy5fX2NoZWNrc3VtID0gXCI1N2Q4ZWZkZTgwZDdcIlxuIl0sIm5hbWVzIjpbXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(app-pages-browser)/./components/HeaderMegaMenu.module.css\n"));

/***/ })

});