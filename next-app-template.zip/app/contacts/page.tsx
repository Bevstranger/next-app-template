'use client'

import { Button, Group, Paper, SimpleGrid, Text, Textarea, TextInput } from '@mantine/core';

import { ContactIconsList } from './ContactIcons';
import classes from './GetInTouch.module.css';

export  default function GetInTouch() {
  return (
    <Paper shadow="md" radius="lg">
      <div className={classes.wrapper}>
        <div className={classes.contacts} >
          <Text fz="lg" fw={700} className={classes.title} c="#fff">
            Контакты
          </Text>

          <ContactIconsList />
        </div>

        <form className={classes.form} onSubmit={(event) => event.preventDefault()}>
          <Text fz="lg" fw={700} className={classes.title}>
            Свяжитесь с нами
          </Text>

          <div className={classes.fields}>
            <SimpleGrid cols={{ base: 1, sm: 2 }}>
              <TextInput label="Имя" placeholder="Ваше имя" />
              <TextInput label="Email" placeholder="Ваш email" required />
            </SimpleGrid>

            <TextInput mt="md" label="Тема" placeholder="Тема сообщения" required />

            <Textarea
              mt="md"
              label="Ваше сообшение"
              placeholder="Пожалуйста напишите нам свое сообщение"
              minRows={3}
            />

            <Group justify="flex-end" mt="md">
              <Button type="submit" className={classes.control}>
                Отправить
              </Button>
            </Group>
          </div>
        </form>
      </div>
    </Paper>
  );
}