import { HeaderMegaMenu } from "@/components/HeaderMegaMenu";




export default function HomePage() {
  return (
    <div >
      
      <p>Hi, world!</p>
      {/* <HeaderMegaMenu /> */}
      
 
    </div>
  );
}
