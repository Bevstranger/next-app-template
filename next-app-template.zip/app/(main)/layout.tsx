import { HeaderMegaMenu } from "@/components/HeaderMegaMenu";
import Head from "next/head";

export default function RootLayout({ children }: { children: React.ReactNode }) {
    return <div>
        <HeaderMegaMenu />
        {children}
        </div>;
}