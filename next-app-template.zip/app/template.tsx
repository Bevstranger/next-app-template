import { HeaderMegaMenu } from "@/components/HeaderMegaMenu";

export default function Template({children}: any) {
    return (
        <div>
            
            <HeaderMegaMenu />
            {children}
        </div>
    );
}