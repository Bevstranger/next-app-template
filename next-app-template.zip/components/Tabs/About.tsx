import React from 'react';

const About = () => {
  return (
    <div>
      <h1>О Компании</h1>
      <p>This is the orders page.</p>
    </div>
  );
};

export default About;