import React from 'react';

const Services = () => {
  return (
    <div>
      <h1>Услуги</h1>
      <p>This is the orders page.</p>
    </div>
  );
};

export default Services;