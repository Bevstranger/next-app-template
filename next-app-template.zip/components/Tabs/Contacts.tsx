import React from 'react';

const Contacts = () => {
  return (
    <div>
      <h1>Контакты</h1>
      <p>This is the orders page.</p>
    </div>
  );
};

export default Contacts;