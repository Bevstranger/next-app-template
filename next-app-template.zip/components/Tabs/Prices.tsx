import React from 'react';

const Prices = () => {
  return (
    <div>
      <h1>Цены</h1>
      <p>This is the orders page.</p>
    </div>
  );
};

export default Prices;