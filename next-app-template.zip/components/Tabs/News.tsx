import React from 'react';

const News = () => {
  return (
    <div>
      <h1>Новости</h1>
      <p>This is the orders page.</p>
    </div>
  );
};

export default News;