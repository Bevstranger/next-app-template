import React from 'react';

const Articles = () => {
  return (
    <div>
      <h1>Статьи</h1>
      <p>This is the orders page.</p>
    </div>
  );
};

export default Articles;