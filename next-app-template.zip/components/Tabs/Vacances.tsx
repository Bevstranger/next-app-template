import React from 'react';

const Vacances = () => {
  return (
    <div>
      <h1>Вакансии</h1>
      <p>This is the orders page.</p>
    </div>
  );
};

export default Vacances;